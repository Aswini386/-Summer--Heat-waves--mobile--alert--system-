# Summer-Heat-Waves-Mobile-Alert-System
A Summer Heat Waves Mobile Alert System notifies users of upcoming heat waves. It collects weather data, predicts heat waves, and sends real-time alerts to users' mobile devices, helping them stay safe during extreme heat.
